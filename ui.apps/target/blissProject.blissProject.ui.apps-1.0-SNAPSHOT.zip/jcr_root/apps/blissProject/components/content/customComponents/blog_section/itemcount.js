
"use strict";
use(function () {
    var count = properties["cardscount"];

    return new Array(Number(count));
});